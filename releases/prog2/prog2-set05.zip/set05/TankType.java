package prog2.exercises.set05;

public enum TankType {
    Cuboid, Cylindrical, Spherical
}
