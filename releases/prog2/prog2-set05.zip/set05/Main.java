package prog2.exercises.set05;

public class Main
{
}
