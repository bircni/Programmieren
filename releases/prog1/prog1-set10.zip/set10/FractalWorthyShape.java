package prog1.exercises.set10;
import java.util.HashMap;

public abstract class FractalWorthyShape {
    HashMap<String, Vector2D> points = new HashMap<>();
}
